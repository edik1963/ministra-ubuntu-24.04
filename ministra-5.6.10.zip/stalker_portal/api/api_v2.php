<?php

echo 'API v2 deprecated';
exit;
