<?php

require_once '../server/common.php';
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce;
if (!\Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::getSafe('enable_soap_api', \false)) {
    \header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
    echo 'SOAP API is not enabled';
    exit;
}
require_once __DIR__ . '/../vendor/rock/phpwsdl/src/Rock/PhpWsdl/class.phpwsdl.php';
use Ministra\Lib\SOAPApi\v1\SoapApiServer;
$api_server = new \Ministra\Lib\SOAPApi\v1\SoapApiServer();
if (isset($_GET['wsdl'])) {
    $api_server->outputWsdl();
} elseif (isset($_GET['docs'])) {
    $api_server->outputDocs();
} elseif (isset($_GET['phpsoapclient'])) {
    $api_server->outputPhpClient();
} else {
    $api_server->handleRequest();
}
