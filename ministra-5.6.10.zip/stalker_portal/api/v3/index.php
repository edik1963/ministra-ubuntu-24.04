<?php

require_once '../../server/common.php';
use Ministra\Lib\c94d43331b986582d35f81652f91e1d1\b858fe3b3e1667e5e053cad0c4874638;
use Ministra\Lib\J8c278cd61d24d3824c1bd406f0f958b0\a4aa95ea1dfa6ea2dddb1f3ddffdb9ca3\E25e1ac96d923536f0085330d7bdff8d4;
$server = new \Ministra\Lib\J8c278cd61d24d3824c1bd406f0f958b0\a4aa95ea1dfa6ea2dddb1f3ddffdb9ca3\E25e1ac96d923536f0085330d7bdff8d4(new \Ministra\Lib\c94d43331b986582d35f81652f91e1d1\b858fe3b3e1667e5e053cad0c4874638());
$server->handleRequest();
