<?php

require_once '../server/common.php';
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b1a35fcd193c18a8e6cbf764479bd5f2\T8bb27b6be28a4e011e4a71ca8a472270;
(new \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b1a35fcd193c18a8e6cbf764479bd5f2\T8bb27b6be28a4e011e4a71ca8a472270())->run();
