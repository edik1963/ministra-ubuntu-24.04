<?php

if (!isset($app)) {
    throw new \Exception('App variable does not define');
}
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce;
use Symfony\Component\Security\Core\Encoder\MessageDigestPasswordEncoder;
$app['twig.options.cache'] = __DIR__ . '/resources/cache/twig';
$theme = [];
$base_twig_path = __DIR__ . '/../resources/views';
foreach (\array_diff(\scandir($base_twig_path), ['..', '.']) as $theme_dir) {
    $theme_dir_path = $base_twig_path . '/' . $theme_dir;
    if (\is_dir($theme_dir_path)) {
        $theme[$theme_dir] = $theme_dir_path . '/';
    }
}
$app['util.path'] = \realpath(__DIR__ . '/../..') . '/deploy/clear_key_util';
$app['themes'] = $theme;
$app['db.host'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('mysql_host');
$app['db.port'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('mysql_port');
$app['db.user'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('mysql_user');
$app['db.password'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('mysql_pass');
$app['db.dbname'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('db_name');
$app['memcache.options'] = ['memcache.options' => ['host' => \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::getSafe('memcache_host', '127.0.0.1'), 'default_timeout' => \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::getSafe('admin_panel_sidebar_cache_time', 1800)]];
$container['security.default_encoder'] = function () {
    return new \Symfony\Component\Security\Core\Encoder\MessageDigestPasswordEncoder('md5', \false, 0);
};
