<?php

if (!isset($app)) {
    throw new \Exception('App variable does not define');
}
