<?php

\defined('PROJECT_PATH') or \define('PROJECT_PATH', __DIR__ . '/../../server');
require_once __DIR__ . '/../vendor/autoload.php';
