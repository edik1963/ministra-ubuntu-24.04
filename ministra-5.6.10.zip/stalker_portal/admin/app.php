<?php

require __DIR__ . '/config/autoload.php';
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce;
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\e19b518dccc8206e14e113c869a7ec85\f1f42f11d53cbf1a52b00c3e1008054b3;
use Silex\Application;
\set_error_handler(function ($errno, $errstr, $errfile, $errline, $errcontext) {
    \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\e19b518dccc8206e14e113c869a7ec85\f1f42f11d53cbf1a52b00c3e1008054b3::K44c3063ee5228ac7df9fd79103066611($errno, $errstr, $errfile, $errline, $errcontext);
}, \E_ALL);
\set_exception_handler(function (\Throwable $t) {
    \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\e19b518dccc8206e14e113c869a7ec85\f1f42f11d53cbf1a52b00c3e1008054b3::T0f1a2e634d9debd7e7fd27ee1fa3e122($t);
});
$_SERVER['TARGET'] = 'ADM';
$locales = [];
$allowed_locales = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::get('allowed_locales');
foreach ($allowed_locales as $lang => $locale) {
    $locales[\substr($locale, 0, 2)] = $locale;
}
$accept_language = !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : \null;
if (!empty($_COOKIE['language']) && (\array_key_exists($_COOKIE['language'], $locales) || \in_array($_COOKIE['language'], $locales))) {
    $language = \substr($_COOKIE['language'], 0, 2);
} else {
    if ($accept_language && \array_key_exists(\substr($accept_language, 0, 2), $locales)) {
        $language = \substr($accept_language, 0, 2);
    } else {
        $language = \key($locales);
    }
}
$locale = $locales[$language];
if (!\headers_sent()) {
    \setcookie('debug_key', '', \time() - 3600, '/');
    \setlocale(\LC_MESSAGES, $locale);
    \setlocale(\LC_TIME, $locale);
    \putenv('LC_MESSAGES=' . $locale);
    \bindtextdomain('stb', \PROJECT_PATH . '/locale');
    \textdomain('stb');
    \bind_textdomain_codeset('stb', 'UTF-8');
}
$app = new \Silex\Application();
$app['allowed_locales'] = $allowed_locales;
$app['language'] = $language;
$app['js_validator_language'] = \in_array($language, ['pt', 'ro', 'dk', 'no', 'nl', 'cz', 'ca', 'ru', 'it', 'fr', 'de', 'se', 'en', 'pt']) ? $language : 'en';
$app['lang'] = $lang = [$language];
$app['used_locale'] = $locale;
$app['debug'] = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\g58b21ad8584095b442bb4ed404e99dce::getSafe('admin_panel_debug', \false);
require __DIR__ . '/config/prod.php';
if ($app['debug']) {
    require __DIR__ . '/config/dev.php';
}
if ($app->offsetExists('test') && $app['test'] && \is_file($file = __DIR__ . '/config/test.php')) {
    require __DIR__ . '/config/test.php';
}
require __DIR__ . '/config/providers.php';
require 'controllers.php';
return $app;
