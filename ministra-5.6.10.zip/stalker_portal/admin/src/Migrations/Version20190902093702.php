<?php

namespace Ministra\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b5bf8769ce13c45c0e7409f5c4ffb626\G6a08eb7ab69b3db3bd9b9a32fdcae288\X7ac492898f2cc5f3f77db562de03b7a3;
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b5bf8769ce13c45c0e7409f5c4ffb626\Q6fede3ac8e186fffe808f5f8ad930697;
use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\acd698e369ae3bdaf2036a1d28a57cc8\T2eae5bf2a9916a2af6b1fe1954cca661;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\ConsoleOutput;
use Symfony\Component\Console\Style\SymfonyStyle;
class Version20190902093702 extends \Doctrine\DBAL\Migrations\AbstractMigration
{
    public function up(\Doctrine\DBAL\Schema\Schema $schema)
    {
        $style = new \Symfony\Component\Console\Style\SymfonyStyle(new \Symfony\Component\Console\Input\ArrayInput([]), new \Symfony\Component\Console\Output\ConsoleOutput());
        $style->createProgressBar();
        $style->success('Start write user device info to statistics table');
        $count = \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b5bf8769ce13c45c0e7409f5c4ffb626\Q6fede3ac8e186fffe808f5f8ad930697::s5fa7dad53bc292a338b388636b767ef5()->c6ba4830096541306ebc3fcdecd113d5(\Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b5bf8769ce13c45c0e7409f5c4ffb626\G6a08eb7ab69b3db3bd9b9a32fdcae288\X7ac492898f2cc5f3f77db562de03b7a3::class)->createQueryBuilder()->select('count(id)')->from('users')->execute()->fetchColumn();
        $style->progressStart($count);
        \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\b5bf8769ce13c45c0e7409f5c4ffb626\Q6fede3ac8e186fffe808f5f8ad930697::s5fa7dad53bc292a338b388636b767ef5()->c6ba4830096541306ebc3fcdecd113d5(\Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\acd698e369ae3bdaf2036a1d28a57cc8\T2eae5bf2a9916a2af6b1fe1954cca661::class)->run($style);
        $style->success('End write user device info to statistics table');
    }
    public function down(\Doctrine\DBAL\Schema\Schema $schema)
    {
        if ($schema->hasTable('users_devices_statistic')) {
            $query = $this->connection->getDatabasePlatform()->getTruncateTableSQL('users_devices_statistic');
            $this->addSql($query);
        }
    }
    public function getDescription()
    {
        return 'Migrate data to devices statistics table';
    }
}
