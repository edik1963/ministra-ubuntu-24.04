<?php

namespace Ministra\Admin\Lib;

use Ministra\Lib\Itv as LibItv;
class Itv extends \Ministra\Lib\Itv
{
    public static function getServices()
    {
        return \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\x6c4456d08c1312d52a4f35d8b06875b7::getInstance()->select('id, CONCAT_WS(". ", cast(number as char), name) as name, number')->from('itv')->orderby('number')->get()->all();
    }
}
