<?php

namespace Ministra\Admin\Command;

use Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\S6cd8b4b5e46af8345d4ca9505e364c14\aea1fc3311ec4546a2e86ebaa6007e74;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
class UpdateClearUtilCommand extends \Symfony\Component\Console\Command\Command
{
    use \Ministra\Admin\Command\ContainerTrait;
    public function configure()
    {
        $this->setName('mtv:clear-util:update')->setDescription('Update clear util');
    }
    public function execute(\Symfony\Component\Console\Input\InputInterface $input, \Symfony\Component\Console\Output\OutputInterface $output)
    {
        (new \Ministra\Lib\k43ef11a9578c2293bdfdd714ecc1b172\S6cd8b4b5e46af8345d4ca9505e364c14\aea1fc3311ec4546a2e86ebaa6007e74($this->container->get('util.path')))->e4964ea811277a032f6a43b12b505bff();
    }
}
